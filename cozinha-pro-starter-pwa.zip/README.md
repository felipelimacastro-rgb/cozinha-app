# Cozinha Pro Starter PWA
Este é um MVP básico do Cozinha Pro.
